﻿using System;
using System.Windows.Forms;

namespace StatusPanel
{
    class Battery
    {
        public static event EventHandler ChargingChanged;
        static bool c = IsCharging();
        public static bool Charging 
        {
            get
            {
             return   c ; 
            }
            set
            {
                if (value != c)
                {
                    c = value;
                    ChargingChanged(null, new EventArgs());
                }
            }
        }
        public static bool IsCharging()
        {
            bool charge = true;
            if (SystemInformation.PowerStatus.PowerLineStatus == PowerLineStatus.Offline)
            {
                return false;
            }
            return charge;
        }
        public static bool IsBatteryPresent()
        {
            bool batt = true;
            if (SystemInformation.PowerStatus.BatteryChargeStatus == BatteryChargeStatus.NoSystemBattery)
            {
                batt = false;
            }
            return batt;


        }

        /*==============START METHODS====================*/
        private static int BatteryTimeRemainingInSeconds()
        {
            int seconds = 0;
            seconds = SystemInformation.PowerStatus.BatteryLifeRemaining;
            return seconds;
        }
        private static int getSeconds()
        {
            int sec = 0;
            sec = (int)BatteryTimeRemainingInSeconds() % 60;
            return sec;
        }
        private static int getMinutes()
        {
            int min = 0;
            min = ((int)BatteryTimeRemainingInSeconds() / 60) % 60;
            return min;
        }
        private static int getHours()
        {
            int hrs = 0;
            hrs = (((int)BatteryTimeRemainingInSeconds() / 60) / 60) % 60;
            return hrs;
        }
        private static int getPowerPercentage()
        {
            int percent = 0;
            percent = Convert.ToInt32(SystemInformation.PowerStatus.BatteryLifePercent * 100);
            return percent;
        }
        private static BatteryChargeStatus getChargeStatus()
        {
            return SystemInformation.PowerStatus.BatteryChargeStatus;
        }
        private static string getChargerStatus()
        {
            string chargerStatus = "Not Connected";
            if (SystemInformation.PowerStatus.PowerLineStatus == PowerLineStatus.Online)
            {
                chargerStatus = "Connected";
            }
            return chargerStatus;
        }
        /*==============EBD METHODS======================*/

        /*================START PROPERTIES===============*/
        public static long TotalSeconds
        {
            get { return BatteryTimeRemainingInSeconds(); }
        }
        public static int HoursRemaining
        {
            get { return getHours(); }
        }
        public static int MinutesRemaining
        {
            get { return getMinutes(); }
        }
        public static int SecondsRemaining
        {
            get { return getSeconds(); }
        }
        public static int BatteryPercentage
        {
            get { return getPowerPercentage(); }
        }
        public static BatteryChargeStatus BatteryChargeState
        {
            get { return getChargeStatus(); }
        }
        public static string ChargerStatus
        {
            get { return getChargerStatus(); }
        }

    }
}
