﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.VisualBasic;
namespace StatusPanel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Battery.ChargingChanged += new EventHandler(Battery_ChargingChanged);
        }
        int height;
        private void Form1_Activated(object sender, EventArgs e)
        {

            Battery_ChargingChanged(null, null);
        }

        void Battery_ChargingChanged(object sender, EventArgs e)
        {
            lblChargeOrTime.Visible = false;
            lblPerc.Visible = false;
            pictureBox1.Visible = false;

            if (Battery.IsCharging())
            {
                lblChargeOrTime.Text = "Charging";
                lblPerc.Location = new Point(105, 173);
                lblChargeOrTime.Location = new Point(84, 221);
                pictureBox1.Height = 56;

            }
            else
            {
                lblPerc.Location = new Point(105, 210);
                lblChargeOrTime.Location = new Point(84, 251);
                pictureBox1.Height = 0;

            }
            bunifuTransition1.AnimationType = BunifuAnimatorNS.AnimationType.Particles;
            bunifuTransition1.ShowSync(lblPerc);
            bunifuTransition1.ShowSync(lblChargeOrTime);
            bunifuTransition1.AnimationType = BunifuAnimatorNS.AnimationType.Rotate;
            bunifuTransition1.ShowSync(pictureBox1);
        }
        private string myIpAddress()
        {
            System.Net.IPAddress[] ips = System.Net.Dns.GetHostEntry(System.Net.Dns.GetHostName()).AddressList;  
            return ips[1].ToString();
        }
        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {/*
            GC.Collect();
            dataGridView1.Rows.Clear();
            try
            {
                foreach (Process pr in Process.GetProcesses())
                {
                    dataGridView1.Rows.Add(pr.Id, pr.ProcessName, pr.MachineName);
                }
            }
            catch (Exception)
            {
            }
          * */
            if (!Battery.Charging)
            {
                if (Battery.SecondsRemaining == -1)
                {
                    lblChargeOrTime.Text = "Calculating";
                }
                else
                {
                    if (Battery.HoursRemaining == 0)
                    {
                        lblChargeOrTime.Text = Battery.MinutesRemaining + "min " + Battery.SecondsRemaining + "sec";
                    }
                    else
                    {
                        if (Battery.HoursRemaining == 1)
                        {
                            lblChargeOrTime.Text = Battery.HoursRemaining + "hr " + Battery.MinutesRemaining + "min " + Battery.SecondsRemaining + "sec";
                        }
                        else
                        {
                            lblChargeOrTime.Text = Battery.HoursRemaining + "hrs " + Battery.MinutesRemaining + "min " + Battery.SecondsRemaining + "sec";
                        }
                    }
                }
            }
            lblTime.Text = DateTime.Now.ToLongTimeString();
            lblDate.Text = DateTime.Now.ToLongDateString();
            Text = lblText.Text;
            bunifuCircleProgressbar1.Value = Battery.BatteryPercentage;
            lblPerc.Text = bunifuCircleProgressbar1.Value.ToString() + "%";
            lblIP.Text = myIpAddress();
            Microsoft.VisualBasic.Devices.Computer comp = new Microsoft.VisualBasic.Devices.Computer();

            lblCompName.Text = SystemInformation.ComputerName;
            lblUserName.Text = SystemInformation.UserName;

            lblProps.Text = comp.Info.OSFullName + "\n" + comp.Info.OSPlatform + "," + comp.Info.OSVersion +
                "\nProcessors : " + Environment.ProcessorCount +
                "\nScreen :" + SystemInformation.PrimaryMonitorSize.Width + " X " +
                SystemInformation.PrimaryMonitorSize.Height + " " + comp.Screen.BitsPerPixel + "(bit)";

            Battery.Charging = Battery.IsCharging();
            if (bunifuCircleProgressbar1.Value >= 75)
            {
                //full battery color 
                bunifuCircleProgressbar1.ProgressColor = Color.SeaGreen;
            }
            if (bunifuCircleProgressbar1.Value >= 50 && bunifuCircleProgressbar1.Value < 75)
            {
                bunifuCircleProgressbar1.ProgressColor = Color.Purple;
            }
            if (bunifuCircleProgressbar1.Value >= 25 && bunifuCircleProgressbar1.Value < 50)
            {
                bunifuCircleProgressbar1.ProgressColor = Color.Tomato;
            }
            if (bunifuCircleProgressbar1.Value >= 0 && bunifuCircleProgressbar1.Value < 25)
            {
                //dead battery color
                bunifuCircleProgressbar1.ProgressColor = Color.Firebrick;
            }
        }

        private void btnHideUnhide_Click(object sender, EventArgs e)
        {
            //expand
            if (this.Height == 90)
            {
                this.Height = height;
                bunifuTransition2.ShowSync(this);
            }
            //collapse
            else if (this.Height == height)
            {
                this.Height = 90;
                bunifuTransition2.ShowSync(this);
            }
        }

        private void lblCompName_Click(object sender, EventArgs e)
        {

        }

        private void bunifuFlatButton3_Click(object sender, EventArgs e)
        {
            //Log off
            StatusPanel.Loading l = new StatusPanel.Loading();
            l.ShowDialog("Log OFF !!", "Please close all applications to avoid data loss", 3);
        }

        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            //shut down
            StatusPanel.Loading l = new StatusPanel.Loading();
            l.ShowDialog("Shutting Down !!", "Please close all applications to avoid data loss", 1);
        }

        private void bunifuFlatButton2_Click(object sender, EventArgs e)
        {
            //restart
            StatusPanel.Loading l = new StatusPanel.Loading();
            l.ShowDialog("Restart !!", "Please close all applications to avoid data loss", 2);
        }

        private void bunifuFlatButton4_Click(object sender, EventArgs e)
        {
            StatusPanel.Loading l = new StatusPanel.Loading();
            l.ShowDialog("Hibernate !!", "Please close all applications to avoid data loss", 4);
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            height = Screen.PrimaryScreen.WorkingArea.Height - 100;
            this.Height = height;
            this.Location = new Point(Screen.PrimaryScreen.WorkingArea.Width - Width - 10, 10);
            foreach (Control c in pnlHeader.Controls)
            {
                if (c is Bunifu.Framework.UI.BunifuImageButton)
                {
                    Bunifu.Framework.UI.BunifuImageButton btn = c as Bunifu.Framework.UI.BunifuImageButton;
                    btn.Cursor = Cursors.Hand;
                    btn.Zoom = 20;
                }
            }
            lblTime.Text = DateTime.Now.ToLongTimeString();
            lblDate.Text = DateTime.Now.ToLongDateString();
            lblCompName.Text = SystemInformation.ComputerName;
            lblUserName.Text = SystemInformation.UserName;
            lblIP.Text = myIpAddress();
        }

        private void lblDate_Click(object sender, EventArgs e)
        {

        }

        private void bunifuTrackbar1_ValueChanged(object sender, EventArgs e)
        {
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            Opacity = (double)trackBar1.Value / 100; Refresh();  
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            Opacity = (double)numericUpDown1.Value / 10;  
        }
    }
}
