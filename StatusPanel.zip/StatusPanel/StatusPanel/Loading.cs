﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
namespace StatusPanel
{
    public enum Mode
    {
        SHUTDOWN,
        RESTART,
        LOGOFF,
        HIBERNATE
    }
    public partial class Loading : Form
    {
        public Loading()
        {
            InitializeComponent();
            new FormMove(this); bunifuCircleProgressbar1.animated = true;
        }
        Timer tm;
        Color[] colors;
        private void Form1_Load(object sender, EventArgs e)
        {
            colors = new Color[]
            {
                Color.FromArgb(60, 118, 61),
                Color.FromArgb(60, 118, 71),
                Color.FromArgb(60, 118, 81),
                Color.FromArgb(60, 118, 91),
                Color.FromArgb(60, 118, 101),
                Color.FromArgb(60, 118, 111),
                Color.FromArgb(60, 118, 121),
                Color.FromArgb(60, 118, 131),
                Color.FromArgb(60, 118, 121),
                Color.FromArgb(60, 118, 111),
                Color.FromArgb(60, 118, 101),
                Color.FromArgb(60, 118, 91),
                Color.FromArgb(60, 118, 81)
            };
            bunifuCircleProgressbar1.ProgressColor = colors[0];
            tm = new Timer();
            tm.Interval = 500;
            tm.Start();
            tm.Tick += Tm_Tick;
        }
        int x = 0;
        private void Tm_Tick(object sender, EventArgs e)
        {
            bunifuColorTransition1.Color1 = colors[x];
            if (x < colors.Length - 1)
            {
                x++;
            }
            else
            {
                x = 0;
            }

            bunifuColorTransition1.Color2 = colors[x];
            timer1.Start();




            Text = dir.ToString();
            GC.Collect();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (bunifuColorTransition1.ProgessValue < 100)
            {
                bunifuColorTransition1.ProgessValue++;
                bunifuCircleProgressbar1.ProgressColor = bunifuColorTransition1.Value;
            }
        }
        ProcessStartInfo ps = new ProcessStartInfo("cmd.exe");
        private void bunifuFlatButton1_Click(object sender, EventArgs e)
        {
            try
            {
                ps.UseShellExecute = false;
                ps.CreateNoWindow = true;
                ps.Arguments = "shutdown.exe /a";
                Process.Start(ps);
                MessageBox.Show("Aborted");
                timer3.Stop();
                Close();
            }
            finally
            {
                Close();
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Close();
        }
        int dir = 1;

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (bunifuCircleProgressbar1.Value == 90)
            {
                dir--;
                bunifuCircleProgressbar1.animationIterval = 8;
            }
            else if (bunifuCircleProgressbar1.Value == 10)
            {
                dir++;
                bunifuCircleProgressbar1.animationIterval = 4;
            }

            bunifuCircleProgressbar1.Value += dir;
        }

        public void ShowDialog(string title, string message, int md)
        {
            label2.Text = title;
            label1.Text = message;
            m = md;
            Operation(md);
            ShowDialog();
        }
        int m;
        private string arguments;
        private void Operation(int modes)
        {
            timer3.Stop();
            timer3.Start();
            switch (modes)
            {
                case 1:
                    arguments = "  /s /t 00 ";
                    bunifuFlatButton1.Text = "Shutdown";
                    break;
                case 2:
                    arguments = " /r /t 00";
                    bunifuFlatButton1.Text = "Restart";
                    break;
                case 3:
                    arguments = " /l ";
                    bunifuFlatButton1.Text = "LogOFF";
                    break;
                case 4:
                    arguments = " /h ";
                    bunifuFlatButton1.Text = "Hibernate";
                    break;
            }
            Text = bunifuFlatButton1.Text + " !!";

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (Convert.ToInt32(label4.Text) != 0)
            {
                label4.Text = Convert.ToString(Convert.ToInt32(label4.Text) - 1);
            }
            else
            {
                bunifuFlatButton1_Click_1(null, null);
                timer3.Stop();
            }
        }

        private void bunifuFlatButton1_Click_1(object sender, EventArgs e)
        {
            try
            {
                Process.Start("shutdown.exe ", arguments);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
