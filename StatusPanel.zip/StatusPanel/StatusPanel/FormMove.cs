﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
namespace StatusPanel
{
    class FormMove
    {
        public Form fm;
        public FormMove(Form frm)
        {
            this.fm = frm;
            fm.MouseDown += new MouseEventHandler(fm_MouseDown);
            fm.MouseMove += new MouseEventHandler(fm_MouseMove);
            fm.MouseUp += new MouseEventHandler(fm_MouseUp);
        }

        private bool isMseDwn = false;
        private System.Drawing.Point lastlocation;
        void fm_MouseDown(object sender, MouseEventArgs e)
        {
            isMseDwn = true;
            lastlocation = e.Location;
        }
        void fm_MouseMove(object sender, MouseEventArgs e)
        {
            if (isMseDwn)
            {
                fm.Location = new System.Drawing.Point((fm.Location.X - lastlocation.X) + e.X, (fm.Location.Y - lastlocation.Y) + e.Y);
                fm.Update();
            }
        }
        void fm_MouseUp(object sender, MouseEventArgs e)
        {
            isMseDwn = false;
        }

    }
}
