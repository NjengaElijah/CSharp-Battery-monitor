﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
namespace StatusPanel
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

        private void running_process()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("ProcessName");
            dt.Columns.Add("ProcessId");
            //using (new Impersonator("adminuser", "", "adminpass"))
            //{
            //    Process[] processes = Process.GetProcessesByName(".", "PCNAME");
            //    //Process.GetProcesses("192.168.20.120")
            //    foreach (Process p in processes)
            //    {
            //        try
            //        {
            //            if (p.MainWindowTitle.Length > 0)
            //            {
            //                dt.Rows.Add();
            //                dt.Rows[dt.Rows.Count - 1][0] = p.MainWindowTitle;
            //                dt.Rows[dt.Rows.Count - 1][2] = p.Id.ToString();
            //            }
            //        }
            //        catch { }
            //    }
            //}

            listBox1.DataSource = dt;
            listBox1.DisplayMember = "ProcessName";
            listBox1.ValueMember = "ProcessId";
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            running_process();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
